# Guia de RORO Tiramisù (per a no programadors)

## 1. Què hi ha a la carpeta
- `index.html` → la web sencera. **Tot el que has d'editar és a dalt de tot del bloc `<script>`**, dins de `const WEB = {…}`.
- `images/` → el logotip i, on hauràs de posar-hi les fotos.
- `robots.txt` i `sitemap.xml` → SEO (per a Google).

## 2. Com completar les dades
Obre `index.html` amb el Bloc de notes (Windows) o TextEdit en mode text pla (Mac), o millor, l'editor gratuït https://vscode.dev.
Canvia només el text entre cometes `"…"`:
- **Preus, noms i descripcions** → dins de `carta`. Per afegir un tiramisú, copia una línia `{ nom: …}` i enganxa-la a sota.
- **Fotos** → posa el fitxer a la carpeta `images/` (ex. `classic.jpg`) i escriu `foto: "images/classic.jpg"`. Recomanat: JPG quadrat, màx. 200 KB (comprimeix a https://squoosh.app).
- **Foto de portada** → `fotoPortada: "images/portada.jpg"`.
- **Horaris** → ex. `["Dilluns", "10:00 – 20:00"]`; per tancat, `"Tancat"`.
- **Instagram / WhatsApp** → enllaços (hi ha exemples dins del fitxer). Mentre estiguin buits, el botó surt apagat.
- **Legal** → titular, NIF, correu i enllaços a les pàgines legals.

Quan canviïs `EL-TEU-DOMINI.com` per la teva adreça real a `index.html` (3 llocs), `robots.txt` i `sitemap.xml`, el SEO quedarà a punt.

## 3. Publicar a Vercel (gratis)
1. Crea un compte a https://github.com i, a https://vercel.com, "Sign up" → "Continue with GitHub".
2. A GitHub: **+ → New repository**, nom `roro-tiramisu`, Public → Create.
3. Dins del repositori: **Add file → Upload files** i arrossega **tot el contingut** de la carpeta (inclosa `images`). Prem **Commit changes**.
4. A Vercel: **Add New… → Project** → tria `roro-tiramisu` → **Import** → **Deploy** (no toquis cap configuració).
5. En 30 segons tindràs una adreça tipus `roro-tiramisu.vercel.app`.

**Per actualitzar la web:** a GitHub obre `index.html` → icona del llapis → canvia el text → **Commit changes**. Vercel la republica sola en 1 minut. Per pujar fotos: **Add file → Upload files** dins `images`.

## 4. Connectar un domini propi
1. Compra el domini (ex. `roro-tiramisu.com`) a Namecheap, Dinahosting, Porkbun, etc.
2. A Vercel: el teu projecte → **Settings → Domains** → escriu el domini → **Add**.
3. Vercel et mostrarà els registres DNS. Al panell del teu registrador (secció DNS) crea:
   - Tipus **A**, nom `@`, valor `76.76.21.21`
   - Tipus **CNAME**, nom `www`, valor `cname.vercel-dns.com`
   (usa els valors exactes que Vercel et mostri, si difereixen).
4. Espera de 10 minuts a unes hores. Vercel posa el candau HTTPS automàticament.

## 5. Després de publicar
- Alta del negoci a **Google Business Profile** (és el que més ajuda al SEO local) i enllaça la web.
- Afegeix el domini a **Google Search Console** i envia `sitemap.xml`.
- Les pàgines legals (avís legal, privacitat, cookies) han de ser textos reals: consulta un gestor o un generador legal fiable. Aquesta web no usa cookies de seguiment, però el mapa de Google pot requerir informar-ne.
